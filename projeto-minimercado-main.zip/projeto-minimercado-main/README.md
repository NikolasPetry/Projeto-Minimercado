I. Projeto Web - Minimercado Vizinhança (Fase 1)

Este projeto consiste no desenvolvimento de um protótipo de site para um minimercado, como parte da avaliação da disciplina. Esta é a Fase 1, focada exclusivamente na estrutura HTML.

II. Funcionalidades Implementadas

O site atualmente possui as seguintes páginas e funcionalidades básicas:

* Página Inicial (`index.html`): Apresenta uma mensagem de boas-vindas ao usuário.
* Página de Produtos (`produtos.html`): Exibe uma lista de produtos divididos em 3 categorias. Cada produto possui imagem, nome, descrição e preço.
* Página de Serviços (`servicos.html`): Descreve os serviços adicionais oferecidos pelo minimercado, como delivery e encomendas.

III. Estrutura

O projeto está estruturado da seguinte forma:

- `index.html`: Página principal.
- `produtos.html`: Página de listagem de produtos.
- `servicos.html`: Página de listagem de serviços.
- `README.md`: Este arquivo de documentação.
- `/images` (opcional): Pasta para armazenar as imagens utilizadas.

IV. Tecnologias Utilizadas

* HTML5: A única tecnologia utilizada nesta fase para a estruturação e semântica do conteúdo.

* Observação: O site foi desenvolvido sem o uso de CSS e JavaScript, conforme os requisitos da Fase 1 do projeto.
